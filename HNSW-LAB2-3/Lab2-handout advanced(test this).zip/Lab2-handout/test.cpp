#include <iostream>
#include <fstream>
#include "src/hnsw.hpp"
#include "util/util.hpp"
#include "util/vecs_io.hpp"
#include "util/ground_truth.hpp"
#include "util/parameter.hpp"

using namespace std;
using namespace HNSWLab;

int main() {

    int threadnum;
    std::cout << "Input Thread" << std::endl;
    std::cin >> threadnum;
    std::printf("load ground truth\n");
    int gnd_n_vec = 100;
    int gnd_vec_dim = 10;
    char *path = "./data/siftsmall/gnd.ivecs";
    int *gnd = read_ivecs(gnd_n_vec, gnd_vec_dim, path);

    std::printf("load query\n");
    int query_n_vec = 100;
    int query_vec_dim = 128;
    path = "./data/siftsmall/query.bvecs";
    int *query = read_bvecs(query_n_vec, query_vec_dim, path);

    std::printf("load base\n");
    int base_n_vec = 10000;
    int base_vec_dim = 128;
    path = "./data/siftsmall/base.bvecs";
    int *base = read_bvecs(base_n_vec, base_vec_dim, path);

    HNSW hnsw;

    size_t report_every = 1000;
    TimeRecord insert_record;
    auto insertstart = std::chrono::high_resolution_clock::now();
    // std::printf("here 1\n");
    for (int i = 0; i < base_n_vec; i++) {
        hnsw.insert(base + base_vec_dim * i, i);

        if (i % report_every == 0) {
            insert_record.reset();
        }
    }
    auto insertend = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> insertdiff = insertend - insertstart;
    double inserttime = insertdiff.count() * 1000;
    // std::printf("here 2\n");
    printf("querying\n");
    vector <vector<int>> test_gnd_l;
    double single_query_time;
    TimeRecord query_record;
    double whole_query_time;
    for(int time=0;time<100;time++) {
        auto start1 = std::chrono::high_resolution_clock::now();
        for (int i = 0; i < gnd_n_vec; i++) {
            vector<int> test_gnd = hnsw.query(query + i * query_vec_dim, gnd_vec_dim);
//        for(int i=0;i<test_gnd.size();i++){
//            std::cout<<test_gnd[i]<<' ';
//        }
//        std::cout<<std::endl;
            test_gnd_l.push_back(test_gnd);
        }
        auto end1 = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> diff1 = end1 - start1;
        whole_query_time+=diff1.count();
    }
    whole_query_time = whole_query_time * 1000.0/100.0;

    double whole_time_threadpool=0;
    std::vector <std::vector<int>> vectors;
    std::vector < std::future < std::vector < int>>> results;
    ThreadPool pool(threadnum);

    for (int i = 0; i < 99; ++i) {
        auto start = std::chrono::high_resolution_clock::now();
        for (int j = 0; j < gnd_n_vec; ++j) {
            results.push_back(pool.enqueue(&HNSW::query, &hnsw, query + j * query_vec_dim, 10));
        }
        for (auto &result: results) {
            result.get();
        }
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> diff = end - start;
        whole_time_threadpool += diff.count();
        results.clear();
    }

    auto start = std::chrono::high_resolution_clock::now();
    for (int j = 0; j < gnd_n_vec; ++j) {
        results.push_back(pool.enqueue(&HNSW::query, &hnsw, query + j * query_vec_dim, 10));
    }
    for (auto &result: results) {
        vectors.push_back(result.get());
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> diff = end - start;
    whole_time_threadpool += diff.count();
    whole_time_threadpool=whole_time_threadpool*1000.0/100.0;

    double recall2 = count_recall(gnd_n_vec, gnd_vec_dim, vectors, gnd);

    //  double whole_time_threadpool = diff.count() * 1000.00;
    double recall = count_recall(gnd_n_vec, gnd_vec_dim, test_gnd_l, gnd);


    std::vector < std::future < std::vector < int>>> results2;
    std::mutex mtx;
    double whole_parallel_time=0;
    for(int time=0;time<100;time++) {
        auto start2 = std::chrono::high_resolution_clock::now();
        std::vector <std::thread> threads(threadnum);
        for (int i = 0; i < threadnum; ++i) {
            threads[i] = std::thread([i, threadnum, &hnsw, &query, query_vec_dim, gnd_n_vec, &mtx, &results2]() {
                for (int j = i; j < gnd_n_vec; j += threadnum) {
                    std::vector<int> result = hnsw.query(query + j * query_vec_dim, 10);
                    std::lock_guard <std::mutex> lock(mtx);
                }
            });
        }
        for (auto &thread: threads) {
            thread.join();
        }
        auto end2 = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> diff2 = end2 - start2;
        whole_parallel_time+=diff2.count();
    }
    whole_parallel_time=whole_parallel_time*1000.00/100.00;
    double recall3 = count_recall(gnd_n_vec, gnd_vec_dim, vectors, gnd);


    printf("whole insert time for 10000 times %.1f ms\n", inserttime);
    printf("average recall: %.3f, total query time for hundred times %.1f ms\n", recall, whole_query_time);
    printf("average recall for Threadpool : %.3f, total query time for hundred times  %.1f ms\n", recall2, whole_time_threadpool);
    printf("average recall for parallel : %.3f, total query time for hundred times  %.1f ms\n", recall3, whole_parallel_time);

    return 0;
}