#include <iostream>
#include "base.hpp"
#include <vector>
#include <cstring>

#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <random>
#include <cassert>
#include <set>
    int m=30;
    int M = m;
    int M_max = m;
    int ef_construction = 100;
    int ef_search = 100;
    int demention=128;
    double mult_ = 1 / log(1.0 * M);

std::default_random_engine level_generator_ = std::default_random_engine(0);

int get_random_level() {
    std::uniform_real_distribution<double> distribution(0.0, 1.0);
    double r = -log(distribution(level_generator_)) * mult_;
    return (int) r;
}

long long int l2distance(const int *a, const int *b, int vec_dim) {
    long dis = 0;
    for (int i = 0; i < vec_dim; ++i) {
        long tmp = a[i] - b[i];
        dis += (tmp * tmp);
    }
    return dis;
}


namespace HNSWLab {

    struct HNSWNode{
        const int* Vector;
        int lable;
        std::vector<std::set<int>> neighbors;
        HNSWNode():neighbors(M_max+1) {}
        HNSWNode(int label) : lable(label), neighbors(M_max+1) {}
    };

    class HNSW : public AlgorithmInterface {
    public:
    private:
        std::vector<HNSWNode> Graph;
        int* Entry;
        int Entry_index;
        int max_height=-1;
        int size=0;
       // std::condition_variable query_cv;
        //std::mutex query_mutex;
        // std::queue<std::pair<const int*, int>> query_queue;
    public:
        HNSW() {Graph.reserve(10001);
            for (int i = 0; i < 10001; ++i) {
                Graph.push_back(HNSWNode(i));
            }}
        //std::mutex graph_mutex;
        void insert(const int *item, int label);
        std::vector<int> query(const int *query, int k);
        std::vector<int> search_layer(const int* q,int ep,int ef,int lp);
        std::set<int> select_neighbors(const int *q, std::vector<int> ep, int ef, int lp);
        ~HNSW() {}
    };
    std::set<int> HNSW::select_neighbors(const int *q, std::vector<int> ep, int ef, int lp) {
        // 使得优先级队列成为一个最小堆
        auto comp = [](const std::pair<long long, int>& a, const std::pair<long long, int>& b) {
            return a.first < b.first;
        };
        std::priority_queue<std::pair<long long, int>, std::vector<std::pair<long long, int>>, decltype(comp)> candidates(comp);

        for (int neighbor_id : ep) {
            long long int dist = l2distance(q, Graph[neighbor_id].Vector, 128);
            candidates.push(std::make_pair(dist, neighbor_id));
            if (candidates.size() > ef) {
                candidates.pop();
            }
        }

        std::set<int> result;
        while (!candidates.empty()) {
            result.insert(candidates.top().second);
            candidates.pop();
        }

        return result;
    }

    std::vector<int> HNSW:: search_layer(const int* q,int ep,int ef,int lp){
        std::set<int> v;
        std::priority_queue<std::pair<long long int, int>> C;
        std::priority_queue<std::pair<long long int, int>> W;

        v.insert(ep);
        C.push(std::make_pair(-l2distance(q,Graph[ep].Vector,128), ep));
        if(l2distance(q, Graph[ep].Vector, 128)==0){
            std::vector<int> newew;
            newew.push_back(2);
            newew.pop_back();
            return newew;
        }
        W.push(std::make_pair(l2distance(q, Graph[ep].Vector, 128), ep));
        while(!C.empty()){
            auto c=C.top();
            int index=c.second;
            C.pop();
            if(W.size()>0&&c.first>W.top().first){
                break;
            }
            std::set<int> check=Graph[index].neighbors[lp];
            int sizee=check.size();
            if(sizee!=0) {
                for (auto e: check) {
                    if (v.find(e) == v.end()) {
                        v.insert(e);
                        long long e_distance = l2distance(Graph[e].Vector, q, 128);
                        if (W.size() < ef || e_distance < W.top().first) {
                            C.push(std::make_pair(-e_distance, e));
                            W.push(std::make_pair(e_distance, e));
                            if (W.size() > ef) {
                                W.pop();
                            }
                        }
                    }
                }
            }
        }
        std::vector<int> tmpp;
        int k=W.size();
        for(int i=0;i<k;i++){
            tmpp.push_back(W.top().second);
            W.pop();
        }
        return tmpp;

    }




    /**
     * input:
     * iterm: the vector to be inserted
     * label: the label(id) of the vector
    */
    void HNSW::insert(const int *item, int label) {
        std::vector<int> W;
        int siz=Graph.size();
        if(label>=Graph.size()){
            Graph.resize(label+1);
        }
        for(int i=siz;i<label+1;i++){
            Graph[i].lable=i;
        }
        int level = get_random_level();

        if(size==0){
            max_height = level;
            int x = *item;
            Entry = &x;
            Entry_index = label;
            level=max_height;
            size++;
        }
        Graph[label].Vector=item;
        Graph[label].lable=label;
        int ep = Entry_index;
        for (int lv = max_height; lv > level; --lv) {
            W = search_layer(item, ep, 1, lv);
            if(W.size()!=0){
                ep = W[W.size()-1];
            }
        }
        for (int lc = std::min(level, max_height); lc >= 0; --lc) {
            W = search_layer(item, ep, ef_construction, lc);
            if(W.size()!=0) {
                ep = W[W.size()-1];
                Graph[label].neighbors[lc] = select_neighbors(item, W, M, lc);
                for (auto e:Graph[label].neighbors[lc]) {
                    Graph[e].neighbors[lc].insert(label);
                    if (Graph[e].neighbors[lc].size() > M_max ){
                        std::vector<int> T(Graph[e].neighbors[lc].begin(), Graph[e].neighbors[lc].end());
                        std::set<int> tmp= select_neighbors(Graph[e].Vector, T, M_max, lc);
                        Graph[e].neighbors[lc]=tmp;
                    }
                }
            }
        }

        if (level>=max_height) {
            max_height = level;
            int x = *item;
            Entry = &x;
            Entry_index = label;
            level=max_height;
            size++;
        }
    }


    /**
     * input:
     * query: the vector to be queried
     * k: the number of nearest neighbors to be returned
     *
     * output:
     * a vector of labels of the k nearest neighbors
    */
    std::vector<int> HNSW::query(const int *query, int k) {
        std::vector<int> res;
        std::vector<int> W;
        std::set<int> S;

        int ep = Entry_index;
        for (int lv = max_height; lv > 1; --lv) {
            W = search_layer(query, ep, 1, lv);
            if(W.size()!=0){
                ep = W[W.size()-1];
            }
        }
        W= search_layer(query,ep,ef_construction,0);
        S= select_neighbors(query,W,k,0);
        W.clear();
        for (int val : S) {
            W.emplace_back(val);
        }
        return W;
    }
}


#include <iostream>
#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <future>

class ThreadPool {
private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;

    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;

public:
    ThreadPool(size_t threads) : stop(false) {
        for (size_t i = 0; i < threads; ++i) {
            workers.emplace_back([this] {
                while (true) {
                    std::function<void()> task;

                    {
                        std::unique_lock<std::mutex> lock(this->queue_mutex);
                        this->condition.wait(lock, [this] { return this->stop || !this->tasks.empty(); });
                        if (this->stop && this->tasks.empty()) return;
                        task = std::move(this->tasks.front());
                        this->tasks.pop();
                    }

                    task();
                }
            });
        }
    }

    template<class F, class... Args>
    auto enqueue(F&& f, Args&&... args)
    -> std::future<typename std::result_of<F(Args...)>::type> {
        using return_type = typename std::result_of<F(Args...)>::type;

        auto task = std::make_shared<std::packaged_task<return_type()>>(
                std::bind(std::forward<F>(f), std::forward<Args>(args)...)
        );

        std::future<return_type> res = task->get_future();
        {
            std::unique_lock<std::mutex> lock(queue_mutex);

            if (stop)
                throw std::runtime_error("stopped ThreadPool");

            tasks.emplace([task]() { (*task)(); });
        }
        condition.notify_one();
        return res;
    }

    ~ThreadPool() {
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            stop = true;
        }
        condition.notify_all();
        for (std::thread &worker : workers)
            worker.join();
    }
};